<?php
header("Access-Control-Allow-Origin: *");
header('Content-Type: application/json');
require_once 'UserModel.php';

$userModel = new UserModel();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Check if this is the addition endpoint
    if (isset($_GET['action']) && $_GET['action'] === 'add') {
        if (isset($_GET['a']) && isset($_GET['b'])) {
            $a = (int)$_GET['a'];
            $b = (int)$_GET['b'];
            $sum = $a + $b;
            echo json_encode([
                'status' => 'success',
                'a' => $a,
                'b' => $b,
                'sum' => $sum
            ]);
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'Both numbers (a and b) are required as query parameters.'
            ]);
        }
    } else {
        // Default: get all users
        $users = $userModel->getAllUsers();
        echo json_encode([
            'status' => 'success',
            'data' => $users
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'status' => 'error',
        'message' => 'Method Not Allowed'
    ]);
}
?>
