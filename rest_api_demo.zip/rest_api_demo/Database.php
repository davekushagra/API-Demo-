<?php
require_once 'config.php';

class Database {
    private $connection;

    public function __construct() {
        $this->connection = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

        //this will check if the connection fails it will show error 
        if ($this->connection->connect_error) { 
            die("Database connection failed: " . $this->connection->connect_error);
        }
    }

    // this function connect with our database if there is no error 
    public function getConnection() {
        return $this->connection;
    }
}
?>
