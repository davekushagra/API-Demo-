<?php
require_once 'UserModel.php';

class UserController {
    private $userModel;

    public function __construct() {
        $this->userModel = new UserModel();
    }

    public function getAllUsers() {
        $users = $this->userModel->getAllUsers();
        echo json_encode([
            'status' => 'success',
            'data' => $users
        ]);
    }

    // You can add more methods here for addUser, deleteUser, etc.
    public function addNumbersGet() {
        if (!isset($_GET['a']) || !isset($_GET['b'])) {
            echo json_encode([
                'status' => 'error',
                'message' => 'Both numbers (a and b) are required as query parameters.'
            ]);
            return;
        }
    
        $a = $_GET['a'];
        $b = $_GET['b'];
        $sum = $a + $b;
    
        echo json_encode([
            'status' => 'success',
            'a' => $a,
            'b' => $b,
            'sum' => $sum
        ]);
    }
    
}
?>
