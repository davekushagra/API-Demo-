<?php
require_once 'Database.php';

class UserModel {
    private $db;

    public function __construct() {
        //creates object of our database class 
        $database = new Database();
        // this db variable stores the  successfull connection from the database 
        $this->db = $database->getConnection();
    }

    public function getAllUsers() {
        $sql = "SELECT id, name FROM users";
        // this result variable stores the retrived vales of id and name from the users table of the sql select query 
        $result = $this->db->query($sql);
        $users = [];

        // this checks if results value is greater than 1.
        // if true, then it will retrieve id and name from the table 
        // and stores in users associative array form [key value pair]
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $users[] = $row;
            }
        }
        return $users;
    }
}
?>
